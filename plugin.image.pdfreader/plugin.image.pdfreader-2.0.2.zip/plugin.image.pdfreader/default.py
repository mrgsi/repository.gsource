from lib.reader import run

run()

from lib.customizer import Customizer

Customizer().run()
